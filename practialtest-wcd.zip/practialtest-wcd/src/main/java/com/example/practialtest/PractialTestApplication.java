package com.example.practialtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PractialTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(PractialTestApplication.class, args);
    }

}
