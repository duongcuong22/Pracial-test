package com.example.practialtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PractialTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
